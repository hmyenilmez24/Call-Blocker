//
//  ViewController.swift
//  CallBlocker
//
//  Created by Mert Yenilmez on 07/09/2018.
//  Copyright © 2018 Mert Yenilmez. All rights reserved.
//



import UIKit
import SQLite
import CallKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    
    /*
     Database settings.
     */
    var database: Connection!
    let NumberTable = Table("Number")
    let ID = Expression<Int>("ID")
    let Number = Expression<String>("Number")
    
    
    
    var list = [String]() // It will be the number list from 'numbers.sqlite3'.
    
    
    
    /*
     TableView settings. It takes inputs from 'list' array.
     */
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return list.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "cell")
        cell.textLabel?.text = list[indexPath.row]
        return cell
    }
    
    
    /*
     Item removing function for 'list' array.
     */
    func delete(element: String) {
        list = list.filter() { $0 != element }
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
    

        
        NumberText.isHidden = false
        BlockButton.isHidden = false
        unBlockButton.isHidden = true
        tableView.isHidden = true
        
        
        
        /*
         Path of 'numbers.sqlite3' document.
         */
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        print(path)
        
        
        
        /*
         Creating 'numbers.sqlite3' and connecting the database.
         */
        do {
            
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let fileUrl = documentDirectory.appendingPathComponent("numbers").appendingPathExtension("sqlite3")
            let database = try Connection(fileUrl.path)
            self.database = database
            
        } catch {
            
            print(error)
            
        }
        
        
        
        /*
         Creating table and columns if not exists.
         */
        let createTable = self.NumberTable.create(ifNotExists: true, block: { (table) in
            
            table.column(self.ID, primaryKey: true)
            table.column(self.Number)
            
        })
        
        do  {
            
            try self.database.run(createTable)
            print("Created table")
            
        } catch {
            
            print(error)
            
        }
        
        
        
        /*
         Adding numbers to 'list' from 'Number' table.
         */
        do{
            
            let stmt = try database.prepare("SELECT Number FROM Number")
            
            for row in stmt {
                
                for (index, name) in stmt.columnNames.enumerated() {
                    
                    print ("\(name):\(row[index]!)")
                    list.append("\(row[index]!)")
                    
                }
                
            }
            self.tableView.reloadData()
            
        }catch{
            
            print("\(error)")
            
        }
        
    }
    
    
    
    /*
     BlockButton adds blocked numbers to the 'list' and database. If entered number not exist then number appends to the 'list' and database.
     */
    var godotHasArrived = true
    
    @IBAction func BlockButton(_ sender: Any) {
        
        let insertNumber = self.NumberTable.insert(self.Number <- NumberText.text!)
        
        for nos in list {
            
            if (NumberText.text! == nos){
                
                godotHasArrived = false
                
            }
            
        }
        
        if (NumberText.text!.count == 10) && (godotHasArrived != false) { // Phone number must consist of 10 digit.
            
            do {
                
                list.append(NumberText.text!)
                try self.database.run(insertNumber)
                self.tableView.reloadData()
                
            } catch {
                
                print(error)
                
            }
            
            let alert = UIAlertController(title: "OK", message: "\(NumberText.text!) Blocked", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        } else {
            
            if (godotHasArrived==false){
                
                let alert = UIAlertController(title: "Error", message: "This number already exist", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }else{
                
                let alert = UIAlertController(title: "Error", message: "Please enter a valid of different phone number", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }
            
        }
        
        NumberText.text=""
        
    }
    
    
    /*
     Removing chosen number from Number column and tableview.
     */
    @IBAction func unBlockButton(_ sender: Any) {
        
        guard let indexPaths = self.tableView.indexPathsForSelectedRows else { // If no selected cells just return.
            
            return
            
        }
        
        for indexPath in indexPaths {
            
            let alice = NumberTable.filter(Number == "\(list[indexPath.row])")
            
            do {
                
                if try database.run(alice.delete()) > 0 {
                    
                    print("deleted '\(list[indexPath.row])'")
                    delete(element: list[indexPath.row])
                    tableView.reloadData()
                    
                } else {
                    
                    print("'\(list[indexPath.row])' not found")
                    
                }
            } catch {
                
                print("delete failed: \(error)")
                
            }
            
        }
        
    }
    
    
    
    /*
     Declaring objects on View Controller.
     */
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var mySegment: UISegmentedControl!
    @IBOutlet weak var NumberText: UITextField!
    @IBOutlet weak var BlockButton: UIButton!
    @IBOutlet weak var unBlockButton: UIButton!
    @IBOutlet weak var BlockLabel: UILabel!
    
    
    
    /*
     Segment controls.
     */
    @IBAction func mySegmentAct(_ sender: Any) {
        
        if mySegment.selectedSegmentIndex == 0 {
            
            NumberText.isHidden = false
            BlockButton.isHidden = false
            unBlockButton.isHidden = true
            BlockLabel.text = "Enter 10 digit phone number"
            tableView.isHidden = true
            
        }
        
        if mySegment.selectedSegmentIndex == 1 {
            
            NumberText.isHidden = true
            BlockButton.isHidden = true
            unBlockButton.isHidden = false
            BlockLabel.text = "Choose number to UnBlock"
            tableView.isHidden = false
            self.tableView.reloadData()
            
        }
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        
    }
    
}


