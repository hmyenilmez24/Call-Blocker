@import Foundation;

FOUNDATION_EXPORT double SQLiteVersionNumber;
FOUNDATION_EXPORT const unsigned char SQLiteVersionString[];

#import <SQLite/SQLite-Bridging.h>
